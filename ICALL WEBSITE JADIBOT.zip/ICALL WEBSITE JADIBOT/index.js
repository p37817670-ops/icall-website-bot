// ICALL JADIBOT - Developer 6288809391162 - Rizal Mustika Grande
// Backend Multi-User Jadibot 24 Jam

const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, makeCacheableSignalKeyStore } = require('@whiskeysockets/baileys')
const express = require('express')
const qrcode = require('qrcode')
const fs = require('fs')
const path = require('path')
const cors = require('cors')
const pino = require('pino')

const app = express()
app.use(cors())
app.use(express.json())
app.use(express.static('./'))

const bots = {}
const SESSIONS_FOLDER = './sessions'
const PAID_FOLDER = './paid'

// Buat folder kalau belum ada
if(!fs.existsSync(SESSIONS_FOLDER)) fs.mkdirSync(SESSIONS_FOLDER)
if(!fs.existsSync(PAID_FOLDER)) fs.mkdirSync(PAID_FOLDER)

console.log('[ICALL] System Starting...')
console.log('[ICALL] Developer: 6288809391162 - Rizal Mustika Grande')
console.log('[ICALL] Mustika Grande Bekasi')

// Fungsi buat bot session baru
async function createBotSession(userId) {
    const sessionPath = path.join(SESSIONS_FOLDER, userId)
    const { state, saveCreds } = await useMultiFileAuthState(sessionPath)
    
    const sock = makeWASocket({
        logger: pino({ level: 'silent' }),
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
        },
        browser: [`ICALL-${userId}`, 'Chrome', '1.0'],
        printQRInTerminal: false
    })

    bots[userId] = { sock, qr: null, connected: false, name: userId, created: new Date() }

    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect, qr } = update
        
        if(qr){
            bots[userId].qr = await qrcode.toDataURL(qr)
            console.log(`[QR] Generated for ${userId} - Dev 6288809391162`)
        }
        
        if(connection === 'open'){
            bots[userId].connected = true
            bots[userId].qr = null
            console.log(`[CONNECTED] ${userId} - Owner 6288809391162`)
        }
        
        if(connection === 'close'){
            const statusCode = lastDisconnect?.error?.output?.statusCode
            console.log(`[DISCONNECT] ${userId} Code ${statusCode}`)
            
            if(statusCode === DisconnectReason.loggedOut){
                delete bots[userId]
                if(fs.existsSync(sessionPath)) fs.rmSync(sessionPath, {recursive: true, force: true})
                console.log(`[LOGOUT] ${userId} deleted`)
            } else {
                // Auto reconnect 3 detik
                setTimeout(() => createBotSession(userId), 3000)
            }
        }
    })

    sock.ev.on('creds.update', saveCreds)

    // Auto reply menu
    sock.ev.on('messages.upsert', async ({messages}) => {
        const msg = messages[0]
        if(!msg.message || msg.key.fromMe) return
        
        const from = msg.key.remoteJid
        const text = msg.message.conversation || msg.message.extendedTextMessage?.text || ''
        const lower = text.toLowerCase()

        if(lower === 'menu' || lower === '.menu' || lower === 'help'){
            await sock.sendMessage(from, { 
                text: `*ICALL JADIBOT - ${userId}*\n\n*Owner:* 6288809391162\n*Dev:* Rizal Mustika Grande\n*Loc:* Mustika Grande Bekasi\n\n*Menu:*\n.menu - Tampilkan menu\n.ping - Cek bot aktif\n.owner - Hubungi owner\n\n*Harga:*\n1 Minggu 50K\n1 Bulan 86K (Best Seller)\n\nBayar via QRIS - Auto Aktif\nChat: 6288809391162` 
            })
        }
        
        if(lower === '.ping' || lower === 'ping'){
            await sock.sendMessage(from, { text: `*PONG!* 🏓\nBot ${userId} aktif!\nDev: 6288809391162\nSpeed: ${Date.now() - (msg.messageTimestamp * 1000)}ms` })
        }
        
        if(lower === '.owner' || lower === 'owner'){
            await sock.sendMessage(from, { text: `*CONTACT OWNER ICALL*\n\n📱 6288809391162\n👤 Rizal Mustika Grande\n📍 Mustika Grande Bekasi\n\nChat untuk sewa jadibot!` })
        }
    })

    return bots[userId]
}

// API: Buat bot baru
app.post('/api/create-bot', async (req, res) => {
    const { nomor, nama } = req.body
    if(!nomor) return res.json({ error: 'Nomor wajib! - Dev 6288809391162' })
    
    const userId = `${nama || 'icall'}_${nomor}`.replace(/[^a-zA-Z0-9]/g,'_')
    
    if(bots[userId]){
        return res.json({ 
            success: true, 
            userId, 
            qr: bots[userId].qr, 
            connected: bots[userId].connected,
            dev: '6288809391162'
        })
    }
    
    await createBotSession(userId)
    console.log(`[NEW BOT] ${userId} created by ${nomor} - Dev 6288809391162`)
    
    res.json({ success: true, userId, message: 'Bot dibuat - Dev 6288809391162', dev: '6288809391162' })
})

// API: Ambil QR
app.get('/api/qr/:userId', (req, res) => {
    const bot = bots[req.params.userId]
    if(!bot) return res.json({ error: 'Bot not found - Chat 6288809391162', dev: '6288809391162' })
    res.json({ qr: bot.qr, connected: bot.connected, dev: '6288809391162' })
})

// API: List semua bot
app.get('/api/bots', (req, res) => {
    const list = Object.keys(bots).map(id => ({ 
        id, 
        connected: bots[id].connected,
        created: bots[id].created
    }))
    res.json({ 
        total: list.length, 
        bots: list,
        developer: '6288809391162',
        owner: 'Rizal Mustika Grande'
    })
})

// API: Payment Callback Tripay (Mode B Auto)
app.post('/callback', (req, res) => {
    const { reference, status, merchant_ref } = req.body
    console.log(`[PAYMENT CALLBACK] ${reference} - ${status} - Dev 6288809391162`)
    
    if(status === 'PAID'){
        fs.writeFileSync(`${PAID_FOLDER}/${reference}.json`, JSON.stringify(req.body))
        fs.writeFileSync(`${PAID_FOLDER}/${merchant_ref}.json`, JSON.stringify(req.body))
        console.log(`[PAID] ${reference} - User can now access jadibot - Dev 6288809391162`)
    }
    
    res.json({ success: true, dev: '6288809391162' })
})

// API: Cek status pembayaran
app.get('/api/check-payment/:ref', (req, res) => {
    const ref = req.params.ref
    const file1 = `${PAID_FOLDER}/${ref}.json`
    
    // Cek di folder paid
    if(fs.existsSync(file1)){
        res.json({ status: 'PAID', dev: '6288809391162' })
    } else {
        // Cek semua file paid
        const files = fs.readdirSync(PAID_FOLDER)
        const found = files.find(f => f.includes(ref) || ref.includes(f.replace('.json','')))
        if(found){
            res.json({ status: 'PAID', dev: '6288809391162' })
        } else {
            res.json({ status: 'UNPAID', dev: '6288809391162' })
        }
    }
})

// Homepage redirect ke index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'))
})

// Info server
app.get('/info', (req, res) => {
    res.json({
        name: 'ICALL JADIBOT',
        developer: '6288809391162',
        owner: 'Rizal Mustika Grande',
        location: 'Mustika Grande, Bekasi',
        version: '2.0 Dual Mode',
        modes: ['Manual QRIS', 'Auto QRIS Tripay'],
        packages: [
            { name: '1 Minggu', price: 50000 },
            { name: '1 Bulan', price: 86000, bestSeller: true }
        ],
        totalBots: Object.keys(bots).length,
        uptime: process.uptime()
    })
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
    console.log(`=================================`)
    console.log(`ICALL JADIBOT RUNNING`)
    console.log(`Developer: 6288809391162`)
    console.log(`Owner: Rizal Mustika Grande`)
    console.log(`Port: ${PORT}`)
    console.log(`URL: http://localhost:${PORT}`)
    console.log(`=================================`)
})